/**
 * Created by MaliT on 2017/9/1.
 */
//返回上一页


window.onload=function(){

    document.getElementById('lastpage').addEventListener("click", function(){
        window.history.back();
    });


}

//兼容火狐、IE8
//显示遮罩层
function showMask(){
    $("#mask").css("height",$(document).height());
    $("#mask").css("width",$(document).width()*(3/4));
   $("#mask").show();




}
//隐藏遮罩层
function hideMask(){
    $("#mask").hide();
}

