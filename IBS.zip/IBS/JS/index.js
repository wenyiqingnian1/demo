/**
 * Created by MaliT on 2017/8/28.
 */



$(document).ready(function(){

    $(function(){
        $("#list-inline li:last").css("border","none");
    })


});
